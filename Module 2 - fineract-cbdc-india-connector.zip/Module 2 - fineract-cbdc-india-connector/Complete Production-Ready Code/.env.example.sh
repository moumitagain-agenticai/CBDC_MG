# Database
DB_PASSWORD=your_db_password

# CBDC API Credentials
CBDC_API_KEY=your_cbdc_api_key
CBDC_API_SECRET=your_cbdc_api_secret

# Fineract
FINERACT_TOKEN=your_fineract_token

# Service
CONFIG_FILE=configs/config.yaml